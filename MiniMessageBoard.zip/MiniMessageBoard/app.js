const express = require("express");
const path = require("path");
const app = express();
app.use(express.urlencoded({extended:true}));
app.set("views", path.join(__dirname, "views"));
//connecting our views folder
app.set( "view engine", "ejs");
//our messagess array
const messages = [{
    text: "hi there!",
    user: "Jeff",
    added: new Date()
},
{
    text: "Hello World!",
    user: "Javi",
    added: new Date()
}
//homepahe that connects our index and messages basically a get request
];
app.get("/", (req, res) => {
  res.render("index", { messages });
});
app.get("/new", (req, res) => {
  res.render("form");
});
app.post("/new", (req, res) => {
  const { user, text } = req.body;

  messages.push({
    user,
    text,
    added: new Date()
  });

  res.redirect("/");
});
//same way we started server as last few assignments
 app.listen(3000, () => {
    console.log("Running on http://localhost:3000");
 });